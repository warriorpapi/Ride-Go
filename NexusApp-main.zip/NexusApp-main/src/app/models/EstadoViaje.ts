export enum EstadoViaje {
    EnCurso = "En Curso",
    Completado = "Completado",
    Cancelado = "Cancelado",
    Pendiente = "Pendiente",
}
