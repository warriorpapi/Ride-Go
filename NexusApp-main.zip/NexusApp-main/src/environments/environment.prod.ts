export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyD5i82Kh1WRZxhoDpy-ti3gXT0TVuslRl8",
    authDomain: "nexxus-80f29.firebaseapp.com",
    projectId: "nexxus-80f29",
    storageBucket: "nexxus-80f29.firebasestorage.app",
    messagingSenderId: "842534189784",
    appId: "1:842534189784:web:be6b4e2cee3b9f1a9435ad"
  }

};
